package productapp;

import java.awt.GridLayout;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.*;

public class ProductApp extends JFrame {

    private JTextField txtCustomerName;
    private JComboBox<String> cmbProduct;
    private JTextField txtPrice;
    private JButton btnProcess;

    public ProductApp() {
        setTitle("Product App");
        setSize(450, 280);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        createMenu();
        createForm();
    }

    // Create the File and Tools menus.
    private void createMenu() {
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);

        JMenu toolsMenu = new JMenu("Tools");

        JMenuItem processItem = new JMenuItem("Process");
        processItem.addActionListener(e -> processSale());

        JMenuItem clearItem = new JMenuItem("Clear");
        clearItem.addActionListener(e -> clearForm());

        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);
    }

    // Build the form where the user enters the sale details.
    private void createForm() {
        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 15));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        txtCustomerName = new JTextField();

        cmbProduct = new JComboBox<>(new String[]{
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        });

        txtPrice = new JTextField();

        btnProcess = new JButton("PROCESS");
        btnProcess.addActionListener(e -> processSale());

        panel.add(new JLabel("Customer Name:"));
        panel.add(txtCustomerName);
        panel.add(new JLabel("Select Product:"));
        panel.add(cmbProduct);
        panel.add(new JLabel("Enter Price:"));
        panel.add(txtPrice);
        panel.add(new JLabel("")); // Leave the first cell empty.
        panel.add(btnProcess);

        add(panel);
    }

    // Check the entered details, calculate the sale and show the result.
    private void processSale() {
        String customerName = txtCustomerName.getText().trim();
        String product = (String) cmbProduct.getSelectedItem();

        if (customerName.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter the customer name.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        double price;
        try {
            price = Double.parseDouble(txtPrice.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid number for the price.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        if (price <= 0) {
            JOptionPane.showMessageDialog(
                    this,
                    "The price must be more than 0.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

    ProductCalculations calculations = new ProductCalculations(price);
        double vat = calculations.GetVat();
        double commission = calculations.GetCommission();
        double total = calculations.GetTotal();

        String details = "Customer Name: " + customerName + "\n"
                + "Product: " + product + "\n"
                + "VAT: R " + vat + "\n"
                + "COMMISSION: R " + commission + "\n"
                + "TOTAL: R " + total;

        JOptionPane.showMessageDialog(
                this,
                details,
                "Message",
                JOptionPane.INFORMATION_MESSAGE
        );

        saveToFile(details);
    }

    // Add the sale details to data.txt without removing earlier entries.
    private void saveToFile(String details) {
        try (PrintWriter writer = new PrintWriter(new FileWriter("data.txt", true))) {
            writer.println("DATA LOG");
            writer.println("*********************************");
            writer.println(details);
            writer.println("*********************************");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Could not save to data.txt.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // Clear the entered details and select the first product again.
    private void clearForm() {
        txtCustomerName.setText("");
        txtPrice.setText("");
        cmbProduct.setSelectedIndex(0);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ProductApp app = new ProductApp();
            app.setVisible(true);
        });
    }
}
