package productapp;

public interface IProductCalculations {

    // Returns the VAT amount for the product.
    double GetVat();

    // Returns the commission amount for the product.
    double GetCommission();

    // Returns the price after VAT and commission are added.
    double GetTotal();
}
